
import { LandmarkTravelService } from './../shared/landmark-travel.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormArray, Validators, FormGroup } from '@angular/forms';
import { LandmarkService } from './../shared/landmark.service';
import { Router } from '@angular/router';
import { Landmark } from './../shared/landmark.model';

@Component({
  selector: 'app-landmark',
  templateUrl: './landmark.component.html',
  styleUrls: ['./landmark.component.css']
})
export class LandmarkComponent implements OnInit {



  //landmarkTravelForms: FormArray = this.fb.array([]);
  landmarkList: Landmark[];
  notification = null;

  constructor(private fb: FormBuilder,
    private landmarkService: LandmarkService,
    private router: Router,
    private service: LandmarkTravelService) { }

  ngOnInit() {
    // this.landmarkService.getLandmarkList()
    //   .subscribe(res => this.landmarkList = res as Landmark[]);
    //     console.log(this.landmarkList );
      this.landmarkService.getLandmarkList()
      .subscribe((data: Landmark[]) => {  
        this.landmarkList = data;  
        console.log(this.landmarkList);
      });  
     
      
  }

  addLandmarkTravelForm() {
   this.router.navigateByUrl('/add');
  }

 
   
  

}
