import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormArray, FormControl, Validators, NgForm, FormGroup } from '@angular/forms';
//import { FormGroup, , Validators} from '@angular/forms';
import { LandmarkService } from '../shared/landmark.service';
import { LandmarkTravelService } from './../shared/landmark-travel.service';
import { Landmark } from './../shared/landmark.model';
import { jsonpCallbackContext } from '@angular/common/http/src/module';
import { stringify } from '@angular/core/src/util';

@Component({
  selector: 'app-add-landmark',
  templateUrl: './add-landmark.component.html',
  styleUrls: ['./add-landmark.component.css']
})
export class AddLandmarkComponent implements OnInit {

 form:FormGroup;
 payLoad='';  

  landmarkTravelForms: FormArray = this.formBuilder.array([]);
  landmarkList: Landmark[];
  notification = null;

  constructor(private formBuilder: FormBuilder,
    private landmarkService: LandmarkService,
    private router: Router,
    private service: LandmarkTravelService) { }

    addForm: FormGroup;  

  ngOnInit() {

    this.addForm = this.formBuilder.group({  
      landmark_Id: [0],  
      landmark_Name: ['', Validators.required],  
      address: ['', [Validators.required, Validators.maxLength(100)]],  
      latitude: ['', [Validators.required, Validators.maxLength(5)]] ,
      longitude: ['', [Validators.required, Validators.maxLength(5)]]  ,
      contact_Number: ['', [Validators.required, Validators.maxLength(10)]]  ,
      distance:[10001],
      Created_Date:[new Date()]
    });  
    
     
  }

   

      
  

  LandmarkTravelList(){
    this.router.navigateByUrl('/');
  }

  addLandmarkTravelForm() {
    this.formBuilder.group({
      landmark_Id: [0],
      landmark_Name: ['', Validators.required],
      address: ['', Validators.required],
      
      latitude: ['', Validators.required],
      longitude: ['', Validators.required],
      distance:[1001],
      contact_Number: [0, Validators.min(1)],
      created_Date:[new Date()]
    });
  }

  
    //this.addLandmarkTravelForm();
    recordSubmit() {
    
    this.service.postLandmarkTravel(this.addForm.value).subscribe(
      data => {  
        alert("Insert Successfully.....");
        //this.router.navigate(['list-emp']);  
      },  
      error => {  
        console.log(this.addForm.value)
        alert(error);  
      });  
      }  
     

 

  showNotification(category) {
    switch (category) {
      case 'insert':
        this.notification = { class: 'text-success', message: 'saved!' };
        break;
      case 'update':
        this.notification = { class: 'text-primary', message: 'updated!' };
        break;
      case 'delete':
        this.notification = { class: 'text-danger', message: 'deleted!' };
        break;

      default:
        break;
    }
    setTimeout(() => {
      this.notification = null;
    }, 3000);
  }

 

}
