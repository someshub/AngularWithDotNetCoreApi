import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { LandmarkComponent } from './landmark/landmark.component';
import { HttpClientModule } from '@angular/common/http';
import { AddLandmarkComponent } from './add-landmark/add-landmark.component';

@NgModule({
  declarations: [
    AppComponent,
    LandmarkComponent,
    AddLandmarkComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      { path: '', component: LandmarkComponent },
      { path: 'add', component: AddLandmarkComponent },
    ]),
    HttpClientModule
  ],
  
  exports: [RouterModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
