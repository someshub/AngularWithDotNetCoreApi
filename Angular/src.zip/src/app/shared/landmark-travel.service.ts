import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Landmark } from './landmark.model';

import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LandmarkTravelService {
  //formData: Landmark;
  

  constructor(private http: HttpClient) { }

  postLandmarkTravel(formData:Landmark) {
    return this.http.post(environment.apiBaseURI + '/Landmark', formData);
  }

  putLandmarkTravel(formData) {
    return this.http.put(environment.apiBaseURI + '/Landmark/' + formData.bankAccountID, formData);
  }

  deleteLandmarkTravel(id) {
    return this.http.delete(environment.apiBaseURI + '/Landmark/' + id);
  }

  getLandmarkTravelList() {
    return this.http.get(environment.apiBaseURI + '/landmark');
  }
}
