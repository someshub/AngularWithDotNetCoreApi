export class Landmark {
     Landmark_Id: number;
     Landmark_Name: string;
     Address: string;
     Latitude: number;
     Longitude: number;
     Contact_Number: number;
     Point_Order: number;
     Distance: number;
     Created_Date: Date;
   
}